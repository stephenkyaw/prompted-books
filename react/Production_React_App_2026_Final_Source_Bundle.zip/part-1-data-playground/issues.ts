type IssueStatus = "open" | "in_progress" | "blocked" | "done";
type IssuePriority = "low" | "medium" | "high";

type Issue = {
  id: string;
  title: string;
  status: IssueStatus;
  priority: IssuePriority;
  assigneeName: string | null;
};

const issues: Issue[] = [
  { id: "issue_1", title: "Fix login", status: "open", priority: "high", assigneeName: "Ada" },
  { id: "issue_2", title: "Improve dashboard", status: "in_progress", priority: "medium", assigneeName: null },
  { id: "issue_3", title: "Add empty state", status: "done", priority: "low", assigneeName: "Grace" },
];

export const visibleIssues = issues.filter((issue) => issue.status !== "done");
export const issueRows = visibleIssues.map((issue) => ({
  id: issue.id,
  label: `${issue.priority.toUpperCase()} - ${issue.title}`,
  assigneeLabel: issue.assigneeName ?? "Unassigned",
}));
