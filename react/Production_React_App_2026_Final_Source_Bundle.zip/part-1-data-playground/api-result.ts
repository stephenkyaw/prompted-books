export type ApiSuccess<T> = { ok: true; data: T };
export type ApiFailure = { ok: false; error: { message: string; statusCode: number } };
export type ApiResult<T> = ApiSuccess<T> | ApiFailure;
