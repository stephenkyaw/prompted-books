import type { Issue, IssueFilters, IssueStatus } from "../types/issue-types";

export async function getIssues(filters: IssueFilters): Promise<Issue[]> {
  const searchParams = new URLSearchParams();
  if (filters.search) searchParams.set("search", filters.search);
  if (filters.status && filters.status !== "all") searchParams.set("status", filters.status);
  const response = await fetch(`/api/issues?${searchParams.toString()}`);
  if (!response.ok) throw new Error("Failed to load issues");
  return response.json();
}

export async function updateIssueStatus(input: { issueId: string; status: IssueStatus }) {
  const response = await fetch(`/api/issues/${input.issueId}/status`, { method: "PATCH", body: JSON.stringify({ status: input.status }) });
  if (!response.ok) throw new Error("Failed to update issue");
  return response.json();
}
