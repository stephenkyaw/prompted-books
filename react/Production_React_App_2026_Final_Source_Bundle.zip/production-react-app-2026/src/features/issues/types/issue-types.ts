export type IssueStatus = "open" | "in_progress" | "blocked" | "done";
export type IssuePriority = "low" | "medium" | "high";
export type Issue = { id: string; title: string; status: IssueStatus; priority: IssuePriority; assigneeName: string | null };
export type IssueFilters = { search?: string; status?: "all" | IssueStatus; page?: number };
