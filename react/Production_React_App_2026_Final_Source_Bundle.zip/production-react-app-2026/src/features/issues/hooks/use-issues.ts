import { useQuery } from "@tanstack/react-query";
import { getIssues } from "../api/issues-api";
import type { IssueFilters } from "../types/issue-types";

export function useIssues(filters: IssueFilters) {
  return useQuery({ queryKey: ["issues", filters], queryFn: () => getIssues(filters), staleTime: 30_000 });
}
