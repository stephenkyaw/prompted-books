import type { Issue } from "../types/issue-types";

export const mockIssues: Issue[] = [
  { id: "issue_1", title: "Login button does not show loading state", description: "The login form submits, but the button stays active.", status: "open", priority: "high", assigneeName: "Ada", createdAt: "2026-06-23" },
  { id: "issue_2", title: "Dashboard chart overflows on mobile", description: "The chart breaks the layout below tablet width.", status: "in_progress", priority: "medium", assigneeName: null, createdAt: "2026-06-22" },
  { id: "issue_3", title: "Add empty state for projects page", description: "New users see a blank area when they have no projects.", status: "done", priority: "low", assigneeName: "Grace", createdAt: "2026-06-21" },
];
