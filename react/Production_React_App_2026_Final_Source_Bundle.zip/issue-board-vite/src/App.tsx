import { useEffect, useRef, useState } from "react";
import { BoardSummary } from "./components/board-summary";
import { IssueList } from "./components/issue-list";
import { SearchInput } from "./components/search-input";
import { StatusFilter } from "./components/status-filter";
import { mockIssues } from "./data/mock-issues";
import { type IssueStatusFilter, useIssueBoard } from "./hooks/use-issue-board";
import type { Issue, IssueStatus } from "./types/issue-types";
import "./App.css";

export default function App() {
  const [issues, setIssues] = useState<Issue[]>(mockIssues);
  const [search, setSearch] = useState(() => localStorage.getItem("issue-board-search") ?? "");
  const [statusFilter, setStatusFilter] = useState<IssueStatusFilter>("all");
  const searchInputRef = useRef<HTMLInputElement | null>(null);
  const { visibleIssues, summary } = useIssueBoard({ issues, search, statusFilter });

  function handleStatusChange(issueId: string, status: IssueStatus) {
    setIssues((current) => current.map((issue) => issue.id === issueId ? { ...issue, status } : issue));
  }
  function clearFilters() { setSearch(""); setStatusFilter("all"); localStorage.removeItem("issue-board-search"); searchInputRef.current?.focus(); }
  function resetBoard() { setIssues(mockIssues); clearFilters(); }

  useEffect(() => { document.title = `${summary.visible} visible issues`; }, [summary.visible]);
  useEffect(() => { localStorage.setItem("issue-board-search", search); }, [search]);
  useEffect(() => { searchInputRef.current?.focus(); }, []);

  return <main className="page"><header className="page-header"><p className="eyebrow">Production React App 2026</p><h1>Issue Board</h1><p>Track bugs, tasks, and workflow status across a project.</p><button className="secondary-button" onClick={resetBoard}>Reset board</button></header><BoardSummary {...summary} /><div className="toolbar"><SearchInput inputRef={searchInputRef} value={search} onChange={setSearch} /><StatusFilter value={statusFilter} onChange={setStatusFilter} /><button className="secondary-button" onClick={clearFilters}>Clear filters</button></div><IssueList issues={visibleIssues} onStatusChange={handleStatusChange} emptyAction={<button className="secondary-button" onClick={clearFilters}>Clear filters</button>} /></main>;
}
