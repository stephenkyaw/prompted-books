export type IssueStatus = "open" | "in_progress" | "blocked" | "done";
export type IssuePriority = "low" | "medium" | "high";

export type Issue = {
  id: string;
  title: string;
  description: string;
  status: IssueStatus;
  priority: IssuePriority;
  assigneeName: string | null;
  createdAt: string;
};
