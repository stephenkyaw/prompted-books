import { useMemo } from "react";
import type { Issue, IssueStatus } from "../types/issue-types";

export type IssueStatusFilter = "all" | IssueStatus;

type UseIssueBoardInput = {
  issues: Issue[];
  search: string;
  statusFilter: IssueStatusFilter;
};

export function useIssueBoard({ issues, search, statusFilter }: UseIssueBoardInput) {
  const normalizedSearch = search.trim().toLowerCase();

  const visibleIssues = useMemo(() => {
    return issues.filter((issue) => {
      const matchesSearch =
        normalizedSearch.length === 0 ||
        issue.title.toLowerCase().includes(normalizedSearch) ||
        issue.description.toLowerCase().includes(normalizedSearch);

      const matchesStatus = statusFilter === "all" || issue.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [issues, normalizedSearch, statusFilter]);

  const summary = useMemo(() => ({
    total: issues.length,
    open: issues.filter((issue) => issue.status === "open").length,
    inProgress: issues.filter((issue) => issue.status === "in_progress").length,
    blocked: issues.filter((issue) => issue.status === "blocked").length,
    done: issues.filter((issue) => issue.status === "done").length,
    visible: visibleIssues.length,
  }), [issues, visibleIssues.length]);

  return { visibleIssues, summary };
}
