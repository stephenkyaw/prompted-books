import type { IssueStatusFilter } from "../hooks/use-issue-board";
const options: Array<{ label: string; value: IssueStatusFilter }> = [
  { label: "All", value: "all" }, { label: "Open", value: "open" }, { label: "In progress", value: "in_progress" }, { label: "Blocked", value: "blocked" }, { label: "Done", value: "done" },
];
export function StatusFilter({ value, onChange }: { value: IssueStatusFilter; onChange: (value: IssueStatusFilter) => void }) {
  return <label className="status-filter"><span>Status</span><select value={value} onChange={(event) => onChange(event.target.value as IssueStatusFilter)}>{options.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</select></label>;
}
