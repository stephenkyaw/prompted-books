import type { ReactNode } from "react";
import type { Issue, IssueStatus } from "../types/issue-types";
import { EmptyState } from "./empty-state";
import { IssueCard } from "./issue-card";

type IssueListProps = { issues: Issue[]; onStatusChange: (issueId: string, status: IssueStatus) => void; emptyAction?: ReactNode };
export function IssueList({ issues, onStatusChange, emptyAction }: IssueListProps) {
  if (issues.length === 0) return <EmptyState title="No issues found" description="Try changing your search text or clearing filters." action={emptyAction} />;
  return <section className="issue-section"><div className="issue-list">{issues.map((issue) => <IssueCard key={issue.id} issue={issue} onStatusChange={onStatusChange} />)}</div></section>;
}
