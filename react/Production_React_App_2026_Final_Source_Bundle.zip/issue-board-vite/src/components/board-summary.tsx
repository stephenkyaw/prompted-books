type Props = { total: number; open: number; inProgress: number; blocked: number; done: number; visible: number };
export function BoardSummary(props: Props) {
  return <section className="board-summary" aria-label="Issue board summary"><div><span>Total</span><strong>{props.total}</strong></div><div><span>Open</span><strong>{props.open}</strong></div><div><span>In progress</span><strong>{props.inProgress}</strong></div><div><span>Blocked</span><strong>{props.blocked}</strong></div><div><span>Done</span><strong>{props.done}</strong></div><div><span>Visible</span><strong>{props.visible}</strong></div></section>;
}
