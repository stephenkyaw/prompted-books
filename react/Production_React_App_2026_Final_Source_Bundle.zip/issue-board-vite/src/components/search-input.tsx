import type { Ref } from "react";
export function SearchInput({ value, onChange, inputRef }: { value: string; onChange: (value: string) => void; inputRef?: Ref<HTMLInputElement> }) {
  return <label className="search-input"><span>Search issues</span><input ref={inputRef} value={value} onChange={(event) => onChange(event.target.value)} placeholder="Search by title or description..." /></label>;
}
