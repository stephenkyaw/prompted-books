import type { Issue, IssueStatus } from "../types/issue-types";

type IssueCardProps = {
  issue: Issue;
  onStatusChange: (issueId: string, status: IssueStatus) => void;
};

export function IssueCard({ issue, onStatusChange }: IssueCardProps) {
  const assigneeLabel = issue.assigneeName ?? "Unassigned";
  return (
    <article className="issue-card">
      <div className="issue-card__header"><h3>{issue.title}</h3><span className="issue-card__priority">{issue.priority}</span></div>
      <p>{issue.description}</p>
      <dl className="issue-card__meta"><div><dt>Status</dt><dd>{issue.status}</dd></div><div><dt>Assignee</dt><dd>{assigneeLabel}</dd></div><div><dt>Created</dt><dd>{issue.createdAt}</dd></div></dl>
      <div className="issue-actions"><button onClick={() => onStatusChange(issue.id, "in_progress")}>Start</button><button onClick={() => onStatusChange(issue.id, "blocked")}>Block</button><button disabled={issue.status === "done"} onClick={() => onStatusChange(issue.id, "done")}>Complete</button></div>
    </article>
  );
}
