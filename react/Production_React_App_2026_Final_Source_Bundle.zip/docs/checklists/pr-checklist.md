# Pull Request Checklist

- TypeScript passes
- Lint passes
- API logic is outside UI components
- Loading, error, and empty states are handled
- Forms validate with Zod
- Server permissions are enforced
- Important behavior is tested
- No secrets are exposed to client code
