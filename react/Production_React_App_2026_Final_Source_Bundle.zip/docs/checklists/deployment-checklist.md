# Deployment Checklist

- Production build passes
- Environment variables are configured
- Auth callback URLs are correct
- API URLs are correct
- Error monitoring is enabled
- Basic E2E smoke test passes
- Rollback plan exists
