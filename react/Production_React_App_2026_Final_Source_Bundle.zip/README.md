# Production React App 2026 - Source Bundle

This bundle contains companion source files for the ebook.

Folders:
- part-1-data-playground: JavaScript/TypeScript fundamentals using issue data
- issue-board-vite: React core mini-project from Part 3
- production-react-app-2026: Next.js production skeleton
- tests/examples: examples for Vitest, MSW, and Playwright
- docs/checklists: PR, deployment, and security checklists
