import { test, expect } from "@playwright/test";

test("user can filter issues", async ({ page }) => {
  await page.goto("/issues");
  await page.getByLabel(/search issues/i).fill("login");
  await expect(page.getByText(/login/i)).toBeVisible();
});
