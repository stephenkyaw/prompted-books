import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { IssueList } from "../../issue-board-vite/src/components/issue-list";

describe("IssueList", () => {
  it("shows an empty state", () => {
    render(<IssueList issues={[]} onStatusChange={vi.fn()} />);
    expect(screen.getByText(/no issues found/i)).toBeInTheDocument();
  });
});
